<?php
/*
Name: FSB for People
Version: 1.0
Author: Fajar Sodik
Blog: www.fsodic.com
Facebook: www.fb.com/presiden.fajar
*/

session_start();
include ('./fs-fn/fs-mobile.fn.php');
include ('./fs-fn/permalink.fn.php');
include ('./database.php');


