[ID]Selamat Datang,
CMS ini bukan CMS berbayar, anda dapat mengunduh gratis di blog official www.fsodic.com.
CMS ini juga kami publikasikan untuk proses belajar CMS Blog

Penginstalan:
Ubah Konfigurasi yang terdapat dalam file "database.php".
Setelah itu, buka /install.php dan isikan data login anda.
----------------------------------------------------------------------------------
[EN]Welcome,
This is not Premium CMS, you can download free in official blog www.fsodic.com.
We are Published this CMS for learn CMS Blog

Installing:
Change configuration in file of "database.php".
After it, open /install.php and input your login data.

----------------------------------------------------------------------------------
Salam Hangat



Fajar Sodik
-------------
CEO & Owner