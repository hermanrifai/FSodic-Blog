<?php

/*
Name: FSB for People
Version: 1.0
Author: Fajar Sodik
Blog: www.fsodic.com
Facebook: www.fb.com/presiden.fajar
*/

echo '
<div id="fs-footer">Copyright &copy; '.date('Y', time()+60*60*8).' <a href="'.$url.'">'.$name.'</a><br />FSB by <a href="http://www.fsodic.com">Fajar Sodik</a></div>
';

?>
